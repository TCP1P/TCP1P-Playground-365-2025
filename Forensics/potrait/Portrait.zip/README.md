# Portrait

nagi

---

## Flag

```
TCP1P{und3rrated_pi3ce_of_4rt_m4de_by_w1reless_keyboard}
```

## Description
> A man had typed a bunch of characters to create a peculiar portrait. Legend said that this portrait may hide a secret beneath it. Can you unveil the secret of the portrait?

## Difficulty
medium

## Tags
ble, vim

## Notes
intentionally left empty

