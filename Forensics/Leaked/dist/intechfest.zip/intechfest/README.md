# intechfest

This repo created to store Intechfest chall, 
if you want to contribute you can fork and 
create pr to this repo.
